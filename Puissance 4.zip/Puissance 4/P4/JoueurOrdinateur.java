package P4;
import java.util.Random;
public class JoueurOrdinateur implements Joueur{

    Random random = new Random();

    private String nom;
    
    public JoueurOrdinateur(String nom){
        this.nom = nom;
    }
    
    public String getNom(){
        return this.nom;
    }
    public void setNom(String nom){
        this.nom = nom;
    }

    public int getPosition(Grille grille){
        boolean valide = false;
        int resultat = 6;
        while(!valide){
            resultat = random.nextInt(Grille.Nb_Colonne);
            valide = resultatValide(grille, resultat);
        }
        System.out.println("L'ordinateur à choisis : " + String.valueOf(resultat + 1));
        return resultat;
    }
    
    public boolean resultatValide(Grille grille, int j){
        return !grille.colonnePleine(j);
    }
}