package P4;
import java.util.ArrayList;
import java.util.Scanner;


public class Menu {
    
    private Scanner scanner;
    
    public Menu() {
        scanner = new Scanner(System.in);
    }
    
    
    public void lancerMenu(){
        int choix;
        boolean quitter = false;
        do {
            System.out.println("=== MENU ===");
            System.out.println("1. Lancer une partie vs ordinateur");
            System.out.println("2. Lancer une partie vs humain");
            System.out.println("3. Options ");
            System.out.println("4. Crédit");
            System.out.println("5. Quitter");
            System.out.print("Votre choix : ");
            
            choix = lireChoix();
            
            switch (choix){
                case 1 :
                    option1();
                    break;
                case 2 :
                    joueurVsJoueur();
                    break;
                case 3 : 
                    option2();
                    break;
                case 4 :
                    option3();
                    break;
                case 5 :
                    quitter = true;
                    break;
                default : 
                    System.out.println("Choix invalide veuillez réesayer");
            }
            System.out.println();
        } while (!quitter);
    }
    
    private int lireChoix(){
        while (!scanner.hasNextInt()){
            System.out.println("Erreur : veuillez entrer un nombre.");
            scanner.next();
            System.out.print("Votre choix : ");
        }
        int choix = scanner.nextInt();
        scanner.nextLine();
        return choix;
    }
    
    private void option1(){
        Arbitre arbitre = new Arbitre("arbitre");
        System.out.println("Choissisez un nom pour votre joueur : ");
        String nomJ = scanner.nextLine();
        arbitre.jouerOrdinateur(nomJ);
    }
    
    private void joueurVsJoueur() {
        Arbitre arbitre = new Arbitre("arbitre");
        String nomJ1, nomJ2;
        
        System.out.print("Joueur 1 : Choisissez un nom : ");
        nomJ1 = scanner.nextLine();
        
        do {
            System.out.print("Joueur 2 : Choisissez un nom différent : ");
            nomJ2 = scanner.nextLine();
            if (nomJ2.equals(nomJ1)) {
                System.out.println("Erreur : Le nom du joueur 2 doit être différent de celui du joueur 1. Veuillez réessayer.");
            }
        } while (nomJ2.equals(nomJ1));
        
        System.out.println("Noms validés : Joueur 1 = " + nomJ1 + ", Joueur 2 = " + nomJ2);
        arbitre.jouerHumain(nomJ1, nomJ2);
    }
    
    private void option2(){
        int choix;
        int change;
        boolean quitter = false;
        do {
            System.out.println("=== OPTIONS ===");
            System.out.println("1. Changer le nombre de lignes");
            System.out.println("2. Changer le nombre de colonnes");
            System.out.println("3. Changer le nombre de symbole à aligner");
            System.out.println("4. Quitter");
            System.out.print("Votre choix : ");
            
            choix = lireChoix();
            
            switch (choix){
                case 1 :
                    change = getNumber(false);
                    Grille.setNbLigne(change);
                    break;
                case 2 : 
                    change = getNumber(true);
                    Grille.setNbColonne(change);;
                    break;
                case 3 : 
                    change = getP4();
                    Direction.setNbAlign(change);
                case 4 :
                    quitter = true;
                    break;
                default : 
                    System.out.println("Choix invalide veuillez réesayer");
            }
            System.out.println();
        } while (!quitter);
    }
    
    private int getNumber(boolean ligne){
        int nombre = 0;
        boolean n1 = false;
        int lg;
        lg = ligne ? 6 : 7;
        while (!n1) {
            try {
                imprimn("Veuillez choisir le nouveau nombre(" + lg + " par défaut)  : ");
                String saisie = scanner.next();  // on lit une chaîne
    
                if (saisie.equalsIgnoreCase("exit")) {
                    imprim("Sortie demandée.");
                    return -1; 
                }
    
                nombre = Integer.parseInt(saisie); // conversion
                verification(nombre);
                n1 = true;
            } catch (NumberFormatException e) {
                imprim("Ce n'est pas un nombre entier, veuillez réessayer");
            } catch (GrilleException e) {
                imprim("On ne peut avoir un nombre inférieur à 0");
            }  catch (ColonnePException e) {
                imprim("Ce nombre est trop grand");
            }
        }
        return nombre;
    }
    
    private int getP4(){
        int nombre = 0;
        boolean n1 = false;
        while (!n1) {
            try {
                imprimn("Veuillez choisir le nouveau nombre à aligner(" + 4 + " par défaut)  : ");
                String saisie = scanner.next();  // on lit une chaîne
    
                if (saisie.equalsIgnoreCase("exit")) {
                    imprim("Sortie demandée.");
                    return -1; 
                }
    
                nombre = Integer.parseInt(saisie); // conversion
                verificationP4(nombre);
                n1 = true;
            } catch (NumberFormatException e) {
                imprim("Ce n'est pas un nombre entier, veuillez réessayer");
            } catch (GrilleException e) {
                imprim("On ne peut avoir un nombre inférieur à 0");
            }  catch (ColonnePException e) {
                imprim("Ce nombre est trop grand");
            }
        }
        return nombre;
    }
    
    public void verification(int nombre) throws GrilleException, ColonnePException {
        if (nombre < 0 ) {
            throw new GrilleException();
        }
        if (nombre > 10) {
            throw new ColonnePException();
        }
    }
    
    public void verificationP4(int nombre) throws GrilleException, ColonnePException  {
        if (nombre < 0 ) {
            throw new GrilleException();
        }
        if (nombre > 10) {
            throw new ColonnePException();
        }
    }
    
    
    private void option3(){
        System.out.println("Application porgrammée par Comparetto Matthieu");
    }
    
    public void imprim(String message) {
        System.out.println(message);
    }
    
    public void imprimn(String message) {
        System.out.print(message);
    }
}