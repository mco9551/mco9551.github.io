package P4;
public class Grille{
    public static int Nb_ligne = 6; 
    public static int Nb_Colonne = 7; 
    private int[][] grille, grille_verification;
    
    public Grille(){
        this.grille_verification = new int[Nb_ligne + 2][Nb_Colonne + 2];
        this.grille = new int[Nb_ligne][Nb_Colonne];
        
    }
    
    public static void setNbLigne(int change){
        Nb_ligne = change;
    }
    
    public static void setNbColonne(int change){
        Nb_Colonne = change;
    }
    
    //return true si la grille est vide
    public boolean grillePleine(){
        for (int i = 0; i < Nb_ligne ; i++){
            for (int j = 0; j < Nb_Colonne; j++){
                if (!caseOccupe(i,j)){
                    return false;
                }
            }
        }
        return true;
    }
    
    public int getGrille(int i, int j){
        return this.grille[i][j];
    }
    
    //return true si la colonne est vide
    public boolean colonnePleine(int colonne){
        for (int i = 0; i < Nb_ligne ; i++){
            if (!caseOccupe(i,colonne)){
                return false;
            }
        }
        return true;
    }
    
    public void remplirCase(int i, int j, boolean joueur) {
         if (joueur){
            grille[i][j] = 1;
            grille_verification[i + 1][j + 1] = 1;
        } if (!joueur){
            grille[i][j] = 2;
            grille_verification[i + 1][j + 1] = 2;
        }
        
    }
    
    public int grilleToGrilleV(int i, int j){
        return grille_verification[i + 1][j + 1];
    }
    
    public int grilleVToGrille(int i, int j){
        if (i == 0 || j == 0){
            return 0;
        }
        return grille_verification[i - 1][j - 1]; 
    }
    //return true si la case est occupe 
    public boolean caseOccupe(int i, int j){
        if (grille[i][j] == 0){
            return false;
        } else {
            return true;
        }
    }
    
    public static boolean nombreToBoolean(int nombre){
        if (nombre == 1){
            return true;
        } else {
            return false;
        }
    }
    
    public static int booleanTonombre(boolean joueur){
        if (joueur){
            return 1;
        } else {
            return 2;
        }
    }
    
    public void afficher_grille(){
        int index = 0;
        for (int i = 0; i < Nb_ligne ; i++){
            for (int j = 0; j < Nb_Colonne; j++){
                index = imprim("|" + symboleCase(caseOccupe(i,j), nombreToBoolean(grille[i][j])) + "|",j, index);
            }
        }
    }
    
    public String symboleCase(boolean b, boolean j){
        if (!b){
            return " ";
        } if (b && j){
            return "x";
        } else {
            return "o";
        }
    }
    
    public int imprim(String message, int saut, int index){
        if (index == 0){
            for (int i = 0; i <Nb_Colonne; i++ ){
                System.out.print(" " + String.valueOf(1 + i) + " ");
            }
            System.out.println();
        }
        if ((saut + 1) % Nb_Colonne == 0){
            System.out.println(message);
        } else {
            System.out.print(message);
        }
        
        return index = 1;
    }
    
    //permet de savoir dans quelle position va finir le nouveau pion, la validité du coup est deja verifié
    public int position(int j){
        for (int i = Nb_ligne - 1; i >= 0; i--) {  // descendre du bas vers le haut
            if (!caseOccupe(i, j)) {
                return i; // première case libre depuis le bas
            }
        }
        return -1; // si la colonne est pleine (aucune case libre)
    }
    
    public boolean verification(int j){
        int i = position(j);
        int aligner = 0;
        return false;
        
    }
}