package P4;
public interface Joueur{
    
    public String getNom();
    public int getPosition(Grille grille);
    public void setNom(String nom);
    
}