package P4;


public class GrilleException extends Exception{
    public GrilleException(String message){
        super(message);
    }
    
    public GrilleException(){
        super();
    }
}