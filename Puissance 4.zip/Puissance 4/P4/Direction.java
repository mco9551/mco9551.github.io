package P4;
import java.util.ArrayList;

public class Direction {
    public static int nbAlign = 4; // Le nombre de symboles à aligner pour gagner

    // Codes de directions
    private static final int BAS = 0;
    private static final int BAS_GAUCHE = 1;
    private static final int GAUCHE = 2;
    private static final int HAUT_GAUCHE = 3;
    private static final int HAUT = 4;
    private static final int HAUT_DROITE = 5;
    private static final int DROITE = 6;
    private static final int BAS_DROITE = 7;


    public static void setNbAlign(int change){
        nbAlign = change;
    }
    // Vérifie si une ligne ou colonne est dans les limites
    public boolean ligneValide(int i) {
        return (i >= 0 && i < Grille.Nb_ligne);    
    }

    public boolean colonneValide(int j) {
        return (j >= 0 && j < Grille.Nb_Colonne);
    }

    // Retourne la nouvelle position après un déplacement dans une direction
    public static int[] nouvellePosition(int i, int j, int dir) {
        switch (dir) {
            case BAS: return new int[] {i + 1, j};
            case BAS_GAUCHE: return new int[] {i + 1, j - 1};
            case GAUCHE: return new int[] {i, j - 1};
            case HAUT_GAUCHE: return new int[] {i - 1, j - 1};
            case HAUT: return new int[] {i - 1, j};
            case HAUT_DROITE: return new int[] {i - 1, j + 1};
            case DROITE: return new int[] {i, j + 1};
            case BAS_DROITE: return new int[] {i + 1, j + 1};
            default: return new int[] {i, j};
        }
    }

    // Vérifie combien de symboles identiques il y a dans une direction donnée
    public int versDirection(int i, int j, int dir, Grille grilleJeu) {
        int[] pos = nouvellePosition(i, j, dir);
        int iTemp = pos[0];
        int jTemp = pos[1];

        if (!ligneValide(iTemp) || !colonneValide(jTemp)) {
            return 0;
        }

        if (grilleJeu.getGrille(i, j) == grilleJeu.getGrille(iTemp, jTemp) && grilleJeu.getGrille(i, j) != 0) {
            return 1 + versDirection(iTemp, jTemp, dir, grilleJeu);
        } else {
            return 0;
        }
    }

    // Vérifie s’il y a une victoire à partir d’une case (i, j)
    public boolean verificationGagne(int i, int j, Grille grilleJeu) {
        // Liste des paires de directions opposées
        int[][] paires = {
            {HAUT, BAS},
            {GAUCHE, DROITE},
            {HAUT_GAUCHE, BAS_DROITE},
            {HAUT_DROITE, BAS_GAUCHE}
        };

        for (int[] couple : paires) {
            int total = 1; // on compte le pion central
            total += versDirection(i, j, couple[0], grilleJeu);
            total += versDirection(i, j, couple[1], grilleJeu);

            if (total >= nbAlign) {
                return true;
            }
        }
        return false;
    }
}
