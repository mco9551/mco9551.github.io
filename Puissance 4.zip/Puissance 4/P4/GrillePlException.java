package P4;
public class GrillePlException extends Exception{
    public GrillePlException(String message){
        super(message);
    }
    
    public GrillePlException(){
        super();
    }
}