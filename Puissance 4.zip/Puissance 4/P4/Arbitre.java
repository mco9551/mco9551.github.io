package P4;
import java.util.Scanner;
import java.util.InputMismatchException;


public class Arbitre{
    
    private static Scanner scanner = new Scanner(System.in);    
    String nom;
    
    public Arbitre(String nom){
        this.nom = nom;
    }
    
    public void jouerOrdinateur(String nom) {
        Grille grilleJeu = new Grille();
        int colonne, ligne;
        Joueur joueurActuel;
        boolean finJeu = false;
        boolean joueurHumain = true;
        Joueur joueurH = new JoueurHumain(nom);
        Joueur Ordinateur = new JoueurOrdinateur("Ordinateur");
        String vainqueur = "";
        Direction dir = new Direction();
    
        do {
            grilleJeu.afficher_grille();
            joueurActuel = joueurHumain ? joueurH : Ordinateur;
            colonne = joueurActuel.getPosition(grilleJeu);
            if (colonne == -1){
                return;
            }
            ligne = grilleJeu.position(colonne);
            grilleJeu.remplirCase(ligne, colonne, joueurHumain);
            boolean victoire = dir.verificationGagne(ligne, colonne, grilleJeu);
            if (victoire) {
                grilleJeu.afficher_grille(); // on affiche la grille victorieuse quand même
                finJeu = true;
                vainqueur = joueurHumain ? nom : "Ordinateur";
            } else if (grilleJeu.grillePleine()) {
                grilleJeu.afficher_grille(); 
                imprim("La grille est pleine : fin de partie !");
                finJeu = true;
                vainqueur = "Personne";
            } else {
                joueurHumain = !joueurHumain; // Change de joueur 
            }
    
        } while (!finJeu);
    
        imprim("La partie est terminée : " + vainqueur + " a gagné !!!");
        //imprim("La partie a été arbitrée par : " + this.nom);
        lancerJeu(nom, "", false);
    }
    
    public void jouerHumain(String nomJ1, String nomJ2) {
        Grille grilleJeu = new Grille();
        int colonne, ligne;
        Joueur joueurActuel;
        boolean finJeu = false;
        boolean joueur1 = true;
        Joueur joueurH1 = new JoueurHumain(nom);
        Joueur joueurH2 = new JoueurHumain(nom);
        String vainqueur = "";
        Direction dir = new Direction();
    
        do {
            grilleJeu.afficher_grille();
            joueurActuel = joueur1 ? joueurH1 : joueurH2;
            colonne = joueurActuel.getPosition(grilleJeu);
            if (colonne == -1){
                return;
            }
            ligne = grilleJeu.position(colonne);
            grilleJeu.remplirCase(ligne, colonne, joueur1);
            boolean victoire = dir.verificationGagne(ligne, colonne, grilleJeu);
            if (victoire) {
                grilleJeu.afficher_grille(); // on affiche la grille victorieuse quand même
                finJeu = true;
                vainqueur = joueur1 ? nomJ1 : nomJ2;
            } else if (grilleJeu.grillePleine()) {
                grilleJeu.afficher_grille(); 
                imprim("La grille est pleine : fin de partie !");
                finJeu = true;
                vainqueur = "Personne";
            } else {
                joueur1 = !joueur1; // Change de joueur 
            }
    
        } while (!finJeu);
    
        imprim("La partie est terminée : " + vainqueur + " a gagné !!!");
        lancerJeu(nomJ1, nomJ2, true);
    }
    
    // mode = false contre l'ordinateur
    public void lancerJeu(String nomJ1, String nomJ2, boolean mode){
        boolean recommencer = true;
        boolean n1 = false;
        while (!n1) {
            try {
                imprimn("Voulez vous recommencer une partie : ");
                recommencer = traitement(scanner.nextLine());
                n1 = true;
            } catch (InputMismatchException e) {
                imprim("Ce n'est pas un nombre entier, veuillez réessayer");
                scanner.next(); // vide l'entrée invalide
            }
        }
        if (recommencer && !mode){
            jouerOrdinateur(nomJ1);
        } if (recommencer && mode){
            jouerHumain(nomJ1, nomJ2);
        }
        
        
    }
    
    public boolean traitement(String chaine){
        if (chaine.equalsIgnoreCase("oui")){
            return true; 
        }
        return false;
    }
    
    
    public String getNomHumain(String args[]){
        if (args.length > 0) {
            return args[0]; // Premier argument passé en ligne de commande
        } else {
            return "nomBasique";
        }
    }
    
    public void imprim(String message){
        System.out.println(message);
    }
    
    public void imprimn(String message) {
        System.out.print(message);
    }
}