package P4;
public class ColonnePException extends Exception{
    public ColonnePException(String message){
        super(message);
    }
    
    public ColonnePException(){
        super();
    }
}