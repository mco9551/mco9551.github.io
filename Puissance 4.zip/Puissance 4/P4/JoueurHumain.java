package P4;

import java.util.Scanner;
import java.util.InputMismatchException;

public class JoueurHumain implements Joueur {

    private static Scanner scanner = new Scanner(System.in);
    private String nom;

    public JoueurHumain(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return this.nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getPosition(Grille grilleActuel) {
        int nombreColonne = 0;
        boolean n1 = false;
        while (!n1) {
            try {
                imprimn("Veuillez choisir un numéro de colonne : ");
                String saisie = scanner.next();  // on lit une chaîne
    
                if (saisie.equalsIgnoreCase("exit")) {
                    imprim("Sortie demandée.");
                    return -1; 
                }
    
                nombreColonne = Integer.parseInt(saisie) - 1; // conversion
                verification(nombreColonne, grilleActuel);
                n1 = true;
            } catch (NumberFormatException e) {
                imprim("Ce n'est pas un nombre entier, veuillez réessayer");
            } catch (GrilleException e) {
                imprim("Ce nombre ne rentre pas dans la grille (" + Grille.Nb_Colonne + " colonnes)");
            } catch (ColonnePException e) {
                imprim("Colonne pleine, choisissez une autre colonne.");
            }
        }
        return nombreColonne;
    }

    public void verification(int nombre, Grille grilleActuel) throws GrilleException, ColonnePException {
        if (nombre < 0 || nombre >= Grille.Nb_Colonne) {
            throw new GrilleException();
        }
        if (grilleActuel.colonnePleine(nombre)) {
            throw new ColonnePException();
        }
    }

    public void imprim(String message) {
        System.out.println(message);
    }
    
    public void imprimn(String message) {
        System.out.print(message);
    }
}
