Pour compiler faire "javac .\MyClass.java"
et pour executer faire "java .\MyClass.java"