import P4.*;
import java.util.ArrayList;
public class MyClass {
  public static void main(String args[]) {
    Menu menu = new Menu();
    menu.lancerMenu();
  }
}